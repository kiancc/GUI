function App() {
  return (
    <>
    <h1>My React App</h1>
    </>
  );
}

export default App;
